#
# Project 9 - Une application web cliente d'une azure fonction qui serve un RS
#

